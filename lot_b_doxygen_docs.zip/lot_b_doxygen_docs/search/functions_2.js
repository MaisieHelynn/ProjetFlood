var searchData=
[
  ['changement_5fcouleur',['changement_couleur',['../_lot___a_8c.html#a8cfce948ac88a403acea10ed2bb1c3b5',1,'Lot_A.c']]],
  ['colorie_5ftache',['colorie_tache',['../_lot___a_8c.html#aefb176307b9237d82cd184d5a053eef5',1,'Lot_A.c']]]
];
