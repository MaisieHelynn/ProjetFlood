var indexSectionsWithContent =
{
  0: "abceilnprstv",
  1: "cp",
  2: "l",
  3: "abceinrstv",
  4: "p"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Files",
  3: "Functions",
  4: "Pages"
};

