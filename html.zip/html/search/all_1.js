var searchData=
[
  ['changement_5fcouleur',['changement_couleur',['../_lot___a_8c.html#aab3803b3e4ecab6f8e21e74116b24725',1,'Lot_A.c']]],
  ['colorie_5ftache',['colorie_tache',['../_lot___a_8c.html#a2ea0438b759eacdc85994ddb0776c57d',1,'Lot_A.c']]]
];
