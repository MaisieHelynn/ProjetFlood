var searchData=
[
  ['pile',['pile',['../structpile.html',1,'']]],
  ['pile_5fcouleur',['pile_couleur',['../structpile__couleur.html',1,'']]],
  ['plateau',['plateau',['../structplateau.html',1,'']]]
];
